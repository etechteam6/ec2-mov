#!/bin/bash
num1=$1
num2=$2
if [ $num1 == $num2 ]; then
	echo "$num1 is equal to $num2"
else
	echo "$num1 is not equal to $num2"
        fi
